const fs = require('fs');
const chalk = require('chalk');
global.owner = ['6285852352107'] 
global.packname = 'suki liat-liat😹'
global.author = 'HanX'
global.botname = 'HanX-Bot'
global.listprefix = ['+','!','.']
global.listv = ['•','●','■','✿','▲','➩','➢','➣','➤','✦','✧','△','❀','○','□','♤','♡','◇','♧','々']
global.tempatDB = 'database.json'
global.pairing_code = true
global.number_bot = ''

global.fake = {
	anonim: 'https://img101.pixhost.to/images/555/555250556_skyzopedia.jpg  ',
	thumbnailUrl: 'https://img101.pixhost.to/images/555/555250556_skyzopedia.jpg',
	thumbnail: fs.readFileSync('./src/media/naze.png'),
	docs: fs.readFileSync('./src/media/fake.pdf'),
	listfakedocs: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/pdf'],
}

global.my = {
	yt: 'https://youtube.com/c/hanx_6666',
	gh: 'https://github.com/hanx-666',
	gc: 'https://chat.whatsapp.com/B5qJIwZHm4VEYZJQEjbJeb',
	ch: '120363373463526398@newsletter',
}

global.limit = {
	free: 30,
	premium: 10000,
	vip: 100000
}

global.uang = {
	free: 10000,
	premium: 1000000,
	vip: 10000000
}

global.mess = {
	key0: 'Apikey mu telah habis silahkan kunjungi\nhttps://my.hitori.pw',
	owner: 'Fitur Khusus Gw!',
	admin: 'Fitur Khusus Admin!',
	botAdmin: 'Bot Bukan Admin!',
	group: 'Fitur Khusus Di Group!',
	private: 'Fitur Khusus Di Privat Chat!',
	limit: 'Limit Anda Telah Habis!',
	prem: 'Khusus User Premium!',
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

global.APIs = {
	hitori: 'https://my.hitori.pw/api',
}
global.APIKeys = {
	'https://my.hitori.pw/api': 'htrkey-awokawok',
}

//~~~~~~~~~~~~~~~< PROCESS >~~~~~~~~~~~~~~~\\

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});
